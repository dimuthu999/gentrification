rm(list=ls())
library(data.table)
library(lfe)
library(stargazer)


# code <- read.csv(file="C:/Users/dnratnadiwakara/Documents/sipp/corefile_codes_2004.csv",stringsAsFactors = FALSE)
# header <- code$variable
# split_points <- code$end
# 
# 
# files = list.files(path = 'C:/Users/dnratnadiwakara/Documents/sipp/coredata', pattern = '.dat',full.names = TRUE)
# temp = lapply(files, function (x) as.data.frame(fread(x,header=FALSE)))
# temp = rbindlist(temp, fill = TRUE)
# 
# t <- temp$V1
# rm(temp)
# 
# core_data <- as.data.frame(matrix(ncol=length(header),nrow=length(t)))
# 
# 
# prev = 0
# i=1
# 
# pb = txtProgressBar(min = 0, max = length(split_points), initial = 0,style = 3)
# 
# for(point in split_points) {
#   setTxtProgressBar(pb,i)
#   core_data[,i] <- sapply(t,function(x) substr(x,prev+1,point))
#   i=i+1
#   prev=point
# }
# 
# names(core_data) <- header
# saveRDS(core_data,file="C:/Users/dnratnadiwakara/Documents/sipp/coredata_raw_2004.rds")
# 
# 
# core_data <- readRDS(file="C:/Users/dnratnadiwakara/Documents/sipp/coredata_raw_2004.rds")
# 
# # codes are same for 2004 and 2008. So using 2008 code file for 2004 data
# keep <- read.csv(file="C:/Users/dnratnadiwakara/Documents/sipp/corefile_codes_2008.csv",stringsAsFactors = FALSE)
# keep <- keep[keep$keep %in% c(1),]$variable
# 
# core_data <- core_data[,keep]
# gc()
# 
# core_data['person_id'] <- paste(core_data$SSUID,core_data$EPPPNUM)
# core_data['white'] <- ifelse(core_data$ERACE==1,1,0)
# core_data$TAGE <- as.numeric(core_data$TAGE)
# core_data$ESEX <- as.numeric(core_data$ESEX)
# core_data$THTOTINC <- as.numeric(core_data$THTOTINC)
# core_data$EHHNUMPP <- as.numeric(core_data$EHHNUMPP)
# core_data['own_home'] <- ifelse(core_data$ETENURE=="1",1,0)
# core_data$TPEARN <- as.numeric(core_data$TPEARN)
# core_data$RFNKIDS <- as.numeric(core_data$RFNKIDS)
# 
# saveRDS(core_data,file="C:/Users/dnratnadiwakara/Documents/sipp/core_data_filtered_2004.rds")


core_data <- readRDS(file="C:/Users/dnratnadiwakara/Documents/sipp/core_data_filtered_2004.rds")

core_data <- core_data[core_data$THTOTINC>0,]

core_data['treat'] <- ifelse(core_data$TFIPSST %in% c("22","28"),1,
                             ifelse(core_data$TFIPSST %in% c("01","12"),NA,0))

core_data['moved'] <- ifelse(core_data$TMOVRFLG %in% c("03","04","05","06"),1,0)
core_data['moved_samecounty'] <- ifelse(core_data$TMOVRFLG %in% c("02"),1,0)
core_data['moved_samestate'] <- ifelse(core_data$TMOVRFLG %in% c("03"),1,0)

core_data['moved_othertate'] <- ifelse(core_data$TMOVRFLG %in% c("04"),1,0) # ,"05","06"
core_data['post'] <- ifelse(core_data$RHCALYR>="2006",1,0) # works better with after 2007

select_states <- c("22","28","40","48","05","47")



controls <- "+EHHNUMPP+I(1+log(THTOTINC))+TAGE+ESEX+RFNKIDS|TFIPSST+RHCALYR+TMETRO|0|TFIPSST"

regs <- list()
regs[[1]] <- felm(as.formula(paste("moved_othertate~post*treat+white+",controls,sep="")),data=core_data[!is.na(core_data$treat) ,])
regs[[2]] <- felm(as.formula(paste("moved_othertate~post*treat+white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$own_home==0,])
regs[[3]] <- felm(as.formula(paste("moved_othertate~post*treat+white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$own_home==1,])

stargazer(regs,type="text",no.space = TRUE,omit.stat = c("f","adj.rsq","ser"))


regs <- list()
regs[[1]] <- felm(as.formula(paste("moved_othertate~factor(RHCALYR)*treat+white+",controls,sep="")),data=core_data[!is.na(core_data$treat) ,])
regs[[2]] <- felm(as.formula(paste("moved_othertate~factor(RHCALYR)*treat+white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$own_home==0,])
regs[[3]] <- felm(as.formula(paste("moved_othertate~factor(RHCALYR)*treat+white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$own_home==1,])

stargazer(regs,type="text",no.space = TRUE,omit.stat = c("f","adj.rsq","ser"))


regs <- list()
regs[[1]] <- felm(as.formula(paste("moved_othertate~post*treat+white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$TFIPSST %in% select_states,])
regs[[2]] <- felm(as.formula(paste("moved_othertate~post*treat+white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$TFIPSST %in% select_states & core_data$own_home==0,])
regs[[3]] <- felm(as.formula(paste("moved_othertate~post*treat+white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$TFIPSST %in% select_states & core_data$own_home==1,])

stargazer(regs,type="text",no.space = TRUE,omit.stat = c("f","adj.rsq","ser"))



regs <- list()
regs[[1]] <- felm(as.formula(paste("moved_othertate~post*treat*white+",controls,sep="")),data=core_data[!is.na(core_data$treat) ,])
regs[[2]] <- felm(as.formula(paste("moved_othertate~post*treat*white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$own_home==0,])
regs[[3]] <- felm(as.formula(paste("moved_othertate~post*treat*white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$own_home==1,])

stargazer(regs,type="text",no.space = TRUE,omit.stat = c("f","adj.rsq","ser"))



regs <- list()
regs[[1]] <- felm(as.formula(paste("moved_othertate~factor(RHCALYR)*treat*white+",controls,sep="")),data=core_data[!is.na(core_data$treat) ,])
regs[[2]] <- felm(as.formula(paste("moved_othertate~factor(RHCALYR)*treat*white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$own_home==0,])
regs[[3]] <- felm(as.formula(paste("moved_othertate~factor(RHCALYR)*treat*white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$own_home==1,])

stargazer(regs,type="text",no.space = TRUE,omit.stat = c("f","adj.rsq","ser"))


core_data['moved_othertate'] <- ifelse(core_data$TMOVRFLG %in% c("04"),1,0) # ,"05","06"
core_data['post'] <- ifelse(core_data$RHCALYR>="2007",1,0) # works better with after 2007
controls <- "+EHHNUMPP+TAGE+ESEX+RFNKIDS|TFIPSST+RHCALYR+TMETRO|0|TFIPSST"


regs <- list()
regs[[1]] <- felm(as.formula(paste("moved_othertate~post*treat*I(1+log(TPEARN))+white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$TPEARN>0,])
regs[[2]] <- felm(as.formula(paste("moved_othertate~post*treat*I(1+log(TPEARN))+white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$TPEARN>0 & core_data$own_home==0,])
regs[[3]] <- felm(as.formula(paste("moved_othertate~post*treat*I(1+log(TPEARN))+white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$TPEARN>0 & core_data$own_home==1,])

stargazer(regs,type="text",no.space = TRUE,omit.stat = c("f","adj.rsq","ser"))



regs <- list()
regs[[1]] <- felm(as.formula(paste("moved_othertate~post*treat*I(1+log(TPEARN))*white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$TPEARN>0,])
regs[[2]] <- felm(as.formula(paste("moved_othertate~post*treat*I(1+log(TPEARN))*white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$TPEARN>0 & core_data$own_home==0,])
regs[[3]] <- felm(as.formula(paste("moved_othertate~post*treat*I(1+log(TPEARN))*white+",controls,sep="")),data=core_data[!is.na(core_data$treat) & core_data$TPEARN>0 & core_data$own_home==1,])

stargazer(regs,type="text",no.space = TRUE,omit.stat = c("f","adj.rsq","ser"))

# ZTRAX: where did new people come from
# ZTRAX: where did the people move to? which states
# Zillow: Impact on rent, houseprices, foreclosures etc
# Small business starts, school performance, crime, voting, lending to small businesses (Call reports) etc
# https://nces.ed.gov/ccd/ccddata.asp
# elevation and mortgage applications after more attention